import { Component } from '@angular/core';
import { FormControl, ReactiveFormsModule,FormGroup ,FormBuilder,Validators} from '@angular/forms';
import { CommonModule } from '@angular/common';

@Component({
  standalone: true,
  selector: 'app-payment-module',
  imports: [ReactiveFormsModule,CommonModule],
  templateUrl: './payment-module.component.html',
  styleUrl: './payment-module.component.css'
})
export class PaymentModuleComponent {
  paymentForm: FormGroup;
  cardNumber = new FormControl('');
  constructor(private fb: FormBuilder) {
    this.paymentForm = this.fb.group({
      cardNumber: ['', [Validators.required, Validators.pattern('^[0-9]{12}$')]],
      expireDate: ['', Validators.required],
      cvv: ['', [Validators.required, Validators.pattern('^[0-9]{3}$')]],
      country: ['', Validators.required],
      address: this.fb.group({
        street: [''],
        city: [''],
        state: [''],
        zip: ['', Validators.required]
      })
    });
  }
  showCardNumberErrors() {
    const cardNumberControl = this.paymentForm.get('cardNumber');
    return cardNumberControl && cardNumberControl.invalid && (cardNumberControl.dirty || cardNumberControl.touched);
  }
  validateCardNumber(event: any) {
    const input = event.target.value;
    const pattern = /^[0-9]*$/;

    if (!pattern.test(input) || input.length >= 12) {
      event.preventDefault();
    }
  }
  showExpiredDateErrors() {
    const expireDateControl = this.paymentForm.get('expireDate');
    return expireDateControl && expireDateControl.invalid && (expireDateControl.dirty || expireDateControl.touched);
  }
  showCVVErrors()
  {
    const cvvNumberControl = this.paymentForm.get('cvv');
    return cvvNumberControl && cvvNumberControl.invalid && (cvvNumberControl.dirty || cvvNumberControl.touched);
  }
  validateCVVNumber(event: any) {
    const input = event.target.value;
    const pattern = /^[0-9]*$/;

    if (!pattern.test(input) || input.length > 3) {
      event.preventDefault();
    }
  }
  showCountryErrors()
  {
    const countryNumberControl = this.paymentForm.get('country');
    return countryNumberControl && countryNumberControl.invalid && (countryNumberControl.dirty || countryNumberControl.touched);
  }
  showZipCodeErrors()
  {
    const zipcodeNumberControl = this.paymentForm.get('zip');
    return zipcodeNumberControl && zipcodeNumberControl.invalid && (zipcodeNumberControl.dirty || zipcodeNumberControl.touched);
  }
  validateZipCodeNumber(event: any) {
    const input = event.target.value;
    const pattern = /^[0-9]*$/;

    if (!pattern.test(input) || input.length > 5) {
      event.preventDefault();
    }
  }
  onSubmit() {
    console.warn(this.paymentForm.value);
  }
}
